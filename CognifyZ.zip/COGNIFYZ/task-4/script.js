const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00']; // Array of desired colors

document.getElementById('colorButton').addEventListener('click', function() {
  const randomIndex = Math.floor(Math.random() * colors.length);  // Random index within color array length
  document.body.style.backgroundColor = colors[randomIndex];
});